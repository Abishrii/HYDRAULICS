import pandas as pd

from edge_runtime import EdgeRuntime

runtime = EdgeRuntime()

sample = pd.read_csv("../models/test_sample.csv")

result = runtime.predict(sample)

print("\nPrediction:\n")
print(result)